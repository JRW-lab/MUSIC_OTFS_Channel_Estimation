function s_mod = modulator(data,S_alphabet)

s_mod = S_alphabet(data);

end